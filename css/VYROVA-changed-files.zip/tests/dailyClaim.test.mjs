// Offline test: in-memory Mongo stand-in (only the operators dailyClaim.js uses) + mocked Telegram getChat.
process.env.BOT_TOKEN = 'TEST';
import assert from 'node:assert/strict';

// ── mini Mongo ──
const eq = (a, b) => (a instanceof Date && b instanceof Date) ? a.getTime() === b.getTime() : a === b;
function matchCond(val, cond) {
    if (cond && typeof cond === 'object' && !(cond instanceof Date)) {
        return Object.entries(cond).every(([op, v]) => {
            if (op === '$exists') return (val !== undefined) === v;
            if (op === '$ne') return !eq(val, v);
            if (op === '$lte') return val !== undefined && val <= v;
            throw new Error('unsupported ' + op);
        });
    }
    return eq(val, cond);
}
function match(doc, f) {
    return Object.entries(f).every(([k, c]) => {
        if (k === '$or') return c.some((x) => match(doc, x));
        if (k === '$and') return c.every((x) => match(doc, x));
        return matchCond(doc[k], c);
    });
}
function apply(doc, u) {
    for (const [k, v] of Object.entries(u.$set || {})) doc[k] = v;
    for (const [k, v] of Object.entries(u.$inc || {})) doc[k] = (doc[k] || 0) + v;
}
class Col {
    constructor() { this.docs = []; }
    async findOne(f) { const d = this.docs.find((x) => match(x, f)); return d ? structuredClone(d) : null; }
    async findOneAndUpdate(f, u) { const d = this.docs.find((x) => match(x, f)); if (!d) return null; apply(d, u); return structuredClone(d); }
    async updateOne(f, u) { const d = this.docs.find((x) => match(x, f)); if (d) apply(d, u); return { matchedCount: d ? 1 : 0 }; }
    async insertOne(doc) { if (this.docs.some((x) => x._id === doc._id)) { const e = new Error('dup'); e.code = 11000; throw e; } this.docs.push(structuredClone(doc)); }
}
const db = { cols: {}, collection(n) { return this.cols[n] ||= new Col(); } };

// ── mocked Telegram ──
let tgBio = ''; let tgMode = 'ok';
globalThis.fetch = async (url) => {
    assert.ok(String(url).endsWith('/getChat'));
    if (tgMode === 'notfound') return { json: async () => ({ ok: false, description: 'Bad Request: chat not found' }) };
    if (tgMode === 'down') return { json: async () => ({ ok: false, description: 'Too Many Requests' }) };
    return { json: async () => ({ ok: true, result: { id: 1, bio: tgBio } }) };
};

const { bioContainsLink, computePath, referralLinkFor, handleDailyClaim, handleDailyClaimStatus } = await import('../lib/dailyClaim.js');
const { DAILY_CLAIM_REWARDS, todayStartBD } = await import('../lib/constants.js');
const any = { $or: [{ multiAccountFlag: { $ne: true } }] };

const call = async (fn, uid = '123456789') => {
    let out; const res = { status(c) { this.c = c; return this; }, json(b) { out = { status: this.c, ...b }; return this; } };
    await fn({}, res, db, uid, { eligibleFilter: any });
    return out;
};
const U = () => db.collection('users').docs[0];
const freeThrottle = () => { delete U().dailyClaimAttemptAt; };
const DAY = 86400000;

// 1) link matching
const L = referralLinkFor('123456789');
assert.equal(L, 'https://t.me/Vyrova_bot?startapp=123456789');
for (const ok of [L, 'hi ' + L + ' bye', 't.me/vyrova_bot?startapp=123456789', 'HTTP://T.ME/VYROVA_BOT?STARTAPP=123456789', 'https://telegram.me/Vyrova_bot?startapp=123456789'])
    assert.equal(bioContainsLink(ok, '123456789'), true, ok);
for (const bad of ['', null, undefined, 'https://t.me/Vyrova_bot?startapp=1234567890', 'https://t.me/Vyrova_bot?startapp=12345678', 'https://t.me/Vyrova_bot?startapp=987654321', 'https://t.me/OtherBot?startapp=123456789', 'vyrova 123456789'])
    assert.equal(bioContainsLink(bad, '123456789'), false, String(bad));
console.log('✓ bio link matching (exact id, case/scheme tolerant, no prefix/suffix id tricks)');

// 2) path computation
const t0 = todayStartBD();
assert.deepEqual(computePath({}, t0), { claimedToday: false, currentDay: 1, completedDays: 0, nextDay: 1 });
assert.deepEqual(computePath({ dailyClaimDay: 3, dailyClaimLastDate: new Date(t0 - DAY) }, t0), { claimedToday: false, currentDay: 4, completedDays: 3, nextDay: 4 });
assert.deepEqual(computePath({ dailyClaimDay: 7, dailyClaimLastDate: new Date(t0 - DAY) }, t0), { claimedToday: false, currentDay: 1, completedDays: 0, nextDay: 1 });
assert.deepEqual(computePath({ dailyClaimDay: 5, dailyClaimLastDate: new Date(t0 - 2 * DAY) }, t0), { claimedToday: false, currentDay: 1, completedDays: 0, nextDay: 1 });
assert.deepEqual(computePath({ dailyClaimDay: 2, dailyClaimLastDate: t0 }, t0), { claimedToday: true, currentDay: 2, completedDays: 2, nextDay: null });
console.log('✓ 7-day path: consecutive advances, Day 7 wraps to Day 1, a missed day restarts');

// 3) failures never pay
db.collection('users').docs.push({ _id: '123456789', wtcBalance: 1000, lifetimeWtcEarned: 1000 });
tgBio = ''; let r = await call(handleDailyClaim);
assert.deepEqual([r.ok, r.error, r.reason], [false, 'bio_not_verified', 'bio_empty']);
r = await call(handleDailyClaim); assert.equal(r.status, 429); assert.equal(r.error, 'daily_claim_too_fast');
freeThrottle(); tgBio = 'my link: https://t.me/Vyrova_bot?startapp=999'; r = await call(handleDailyClaim);
assert.deepEqual([r.ok, r.reason], [false, 'bio_missing_link']);
freeThrottle(); tgMode = 'notfound'; r = await call(handleDailyClaim); assert.equal(r.reason, 'bio_unavailable');
freeThrottle(); tgMode = 'down'; r = await call(handleDailyClaim); assert.equal(r.reason, 'bio_check_failed');
tgMode = 'ok';
assert.equal(U().wtcBalance, 1000); assert.equal(db.collection('dailyClaims').docs.length, 0);
console.log('✓ empty / wrong link / unreachable / Telegram-down → clear reason, balance untouched, throttled');

// 4) success + duplicate protection + status
freeThrottle(); tgBio = 'VYROVA ' + L; r = await call(handleDailyClaim);
assert.deepEqual([r.ok, r.reward, r.day, r.balance], [true, 20, 1, 1020]);
assert.equal(U().wtcBalance, 1020); assert.equal(U().lifetimeWtcEarned, 1020);
freeThrottle(); r = await call(handleDailyClaim); assert.equal(r.error, 'daily_claim_already_done'); assert.equal(U().wtcBalance, 1020);
const st = await call(handleDailyClaimStatus); assert.deepEqual([st.claimedToday, st.currentDay, st.completedDays, st.referralLink], [true, 1, 1, L]);
assert.equal(db.collection('dailyClaims').docs.length, 1);
console.log('✓ Day 1 pays +20 once; repeat same day blocked; history row + status correct');

// 5) full week then wrap, exact amounts
let expectBal = 1020;
for (let day = 2; day <= 7; day++) {
    U().dailyClaimLastDate = new Date(todayStartBD() - DAY); freeThrottle();   // pretend last claim was yesterday
    r = await call(handleDailyClaim); expectBal += DAILY_CLAIM_REWARDS[day - 1];
    assert.deepEqual([r.ok, r.day, r.reward, U().wtcBalance], [true, day, DAILY_CLAIM_REWARDS[day - 1], expectBal], 'day ' + day);
    db.collection('dailyClaims').docs.pop();   // (history key is per real day; clear so the sim can continue)
}
assert.deepEqual(DAILY_CLAIM_REWARDS, [20, 40, 60, 80, 100, 120, 140]);
U().dailyClaimLastDate = new Date(todayStartBD() - DAY); freeThrottle();
r = await call(handleDailyClaim); assert.deepEqual([r.ok, r.day, r.reward], [true, 1, 20]); // after Day 7 → Day 1
db.collection('dailyClaims').docs.pop();
U().dailyClaimLastDate = new Date(todayStartBD() - 3 * DAY); freeThrottle();      // missed days
r = await call(handleDailyClaim); assert.deepEqual([r.ok, r.day, r.reward], [true, 1, 20]);
console.log('✓ Day 1…7 = 20/40/60/80/100/120/140, Day 7 → Day 1, missed day → Day 1');

// 6) parallel requests: exactly one payout
db.collection('users').docs.length = 0; db.collection('dailyClaims').docs.length = 0;
db.collection('users').docs.push({ _id: '123456789', wtcBalance: 0 });
const burst = await Promise.all(Array.from({ length: 8 }, () => call(handleDailyClaim)));
assert.equal(burst.filter((x) => x.ok).length, 1); assert.equal(U().wtcBalance, 20);
// and even with the throttle bypassed, the atomic day gate pays once
U().dailyClaimLastDate = new Date(todayStartBD() - DAY); U().dailyClaimDay = 1; freeThrottle();
const w = U(); const origFind = Col.prototype.findOneAndUpdate;
const gateRace = await Promise.all([call(handleDailyClaim), (async () => { freeThrottle(); return call(handleDailyClaim); })()]);
assert.ok(gateRace.filter((x) => x.ok).length <= 1);
console.log('✓ 8 parallel claims → exactly 1 payout; no double credit');

// 7) banned / locked
db.collection('users').docs.length = 0; db.collection('users').docs.push({ _id: '123456789', wtcBalance: 5, isBanned: true });
r = await call(handleDailyClaim); assert.deepEqual([r.status, r.error], [403, 'banned']);
console.log('✓ banned user blocked');
console.log('\nALL BACKEND TESTS PASSED');
